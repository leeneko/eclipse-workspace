
public class Question3 {
	
	private int paper; // 종이량
	private int ink; // 잉크량
	private String model; // 모델명
	private boolean power; // 전원

	public static void main(String[] args) {
		
		
	}
	
	public void print() { // 출력
		
	}
	public void scan() { // 스캔
		
	}
	public void copy() { // 복사
		
	}
	public void fax() { // 팩스
		
	}
}
