package Qustion4;

public class Mouse {
	public String product_Id;
	public String price;
	
	public void rightClick() { System.out.println("오른쪽 클릭!"); }
	public void leftClick() { System.out.println("왼쪽 클릭!"); }
}
