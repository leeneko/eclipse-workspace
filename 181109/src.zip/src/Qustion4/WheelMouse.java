package Qustion4;

public class WheelMouse extends Mouse {
	public String product_Color;
	
	public void wheelUp() { System.out.println("위로 올리기!"); }
	public void wheelDown() { System.out.println("아래로 내리기!"); }
}
