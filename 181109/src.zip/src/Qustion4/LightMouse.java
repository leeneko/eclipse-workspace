package Qustion4;

public class LightMouse extends WheelMouse {
	public String light_Color;
	public String brightness;
	
	public void shineLight() { System.out.println("빛을 비추다!"); }
}
