package Question5;

public class Train extends Vehicle {
	public void go() {
		System.out.println("기차타고 부산간다");
	}
}
