package Question5;

public class Bus extends Vehicle {
	public void go() {
		System.out.println("버스타고 부산간다");
	}
}
