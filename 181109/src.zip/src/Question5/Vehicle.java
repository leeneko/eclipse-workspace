package Question5;

public abstract class Vehicle {
	public abstract void go();
}
