package Question5;

public class Airplane extends Vehicle {
	public void go() {
		System.out.println("비행기 타고 부산간다.");
	}
}
