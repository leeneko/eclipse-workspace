package solution;

public class S37 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Expressions expressions = new Expressions();
		System.out.println(expressions.expressions(15));
	}
	
	
}
