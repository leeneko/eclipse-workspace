package solution;

public class S32 {

	public static void main(String[] args) {
		System.out.println(change124(10));
	}

	private static String change124(int i) {
		// 10진법의 1 > 1
		// 10진법의 2 > 2
		// 10진법의 3 > 4
		// 10진법의 4 > 11
		// 10진법의 5 > 12
		// 10진법의 6 > 14
		// 10진법의 7 > 21
		// 10진법의 8 > 22
		// 10진법의 9 > 24
		// 10진법의 10 > 41
		// 11 > 42
		// 12 > 44
		// 13 > 111
		// 14 > 112
		// 15 > 114
		// 16 > 121
		// 17 > 122
		// 18 > 124
		// 19 > 141
		// 20 > 142
		// 21 > 144
		// 22 > 211
		String output = "";
		
		

		return output;
	}

}
