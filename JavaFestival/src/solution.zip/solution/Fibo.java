package solution;

import java.util.Scanner;

public class Fibo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int input = sc.nextInt();
		sc.close();
		System.out.println(fibo(input));
	}

	public static int fibo(int input) {
		// 1 1 2 3 5 8 13 21 34 55 89 ...
		
		
		return 0;
	}

}
