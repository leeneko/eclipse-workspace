package socket;

public class IpDef {
	private static String IP = "59.3.96.19";

	public static String getIP() {
		return IP;
	}
	
}
