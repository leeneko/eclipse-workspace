package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import VO.CarVO;
import VO.MemberVO;

public class DAO {
	private Connection conn = null;
	private PreparedStatement pstm = null;
	private ResultSet rs = null;
	private MemberVO vo = null;
	private CarVO vo2 = null;

	public MemberVO login(String id, String pw) {
		MemberVO vo = new MemberVO();
		try {
			conn = DBConnection.getConn();
			String sql = "SELECT * FROM MEMBER WHERE ID = ? AND PW = ?";
			pstm = conn.prepareStatement(sql);
			pstm.setString(1, id);
			pstm.setString(2, pw);
			rs = pstm.executeQuery();
			while (rs.next()) {
				vo.setId(rs.getString("ID"));
				vo.setPw(rs.getString("PW"));
				vo.setPw(rs.getString("NAME"));
				vo.setPhone(rs.getString("PHONE"));
				vo.setPost(rs.getInt("POST"));
				vo.setAddress(rs.getString("ADDRESS"));
				vo.setLicense(rs.getString("LICENSE"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return vo;
	}

	public int join(MemberVO vo) { // 회원가입
		int result = 0;
		try {
			conn = DBConnection.getConn();
			String sql = "INSERT INTO member VALUES (?, ?, ?, ?, ?, ?, ?)";
			pstm = conn.prepareStatement(sql);
			pstm.setString(1, vo.getId());
			pstm.setString(2, vo.getPw());
			pstm.setString(3, vo.getName());
			pstm.setString(4, vo.getPhone());
			pstm.setInt(5, vo.getPost());
			pstm.setString(6, vo.getAddress());
			pstm.setString(7, vo.getLicense());
			result = pstm.executeUpdate();
			if (result > 0) {
				result = 1;
			}
		} catch (SQLException e) {
			// 참고 사이트 : http://rosebud90.tistory.com/entry/18-Oracle-Exception-%EC%98%88%EC%99%B8%EC%B2%98%EB%A6%AC
			String[] except = e.toString().split(" ");
			if (except[1].equals("ORA-00001:")) { // 아이디 중복 오류
				result = 2;
			}
		} catch (Exception e) {
			return 0;
		} finally {
			close();
		}
		return result; // 0. 알 수 없는 회원가입 오류, 1. 회원가입 성공, 2. 아이디 중복 오류  
	}

	private void close() {
		// TODO Auto-generated method stub
		try {
			if (rs != null)
				rs.close();
			if (pstm != null)
				pstm.close();
			if (conn != null)
				conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public MemberVO idsearch(String inputName, String inputPhone) {
		try {
			conn = DBConnection.getConn();
			String sql = "SELECT * FROM MEMBER WHERE NAME LIKE ? AND PHONE LIKE ?";
			pstm = conn.prepareStatement(sql);

			pstm.setString(1, inputName);
			pstm.setString(2, inputPhone);

			rs = pstm.executeQuery();

			while (rs.next()) {
				String id = rs.getString("id");
				String pw = rs.getString("pw");
				int post = rs.getInt("post");
				String address = rs.getString("address");
				String license = rs.getString("license");
				vo = new MemberVO(id, pw, inputName, inputPhone, post, address, license);
			}
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			close();
		}
		return vo;
	}

	public MemberVO pwsearch(String inputName, String inputId, String inputPhone) {
		try {
			conn = DBConnection.getConn();
			String sql = "SELECT * FROM MEMBER WHERE NAME LIKE ? AND ID LIKE ? AND PHONE LIKE ?";
			pstm = conn.prepareStatement(sql);

			pstm.setString(1, inputName);
			pstm.setString(2, inputId);
			pstm.setString(3, inputPhone);

			rs = pstm.executeQuery();

			while (rs.next()) {
				String id = rs.getString("id");
				String pw = rs.getString("pw");
				int post = rs.getInt("post");
				String address = rs.getString("address");
				String license = rs.getString("license");
				vo = new MemberVO(id, pw, inputName, inputPhone, post, address, license);
			}
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			close();
		}
		return vo;
	}

	public int insertCar(CarVO vo2) {
		int result = 0;
		try {
			conn = DBConnection.getConn();
			// INSERT INTO car VALUES ('73호4296', '소형', '넥스트 스파크', '등록', 30000, 180, 1980);
			String sql = "INSERT INTO car VALUES (?, ?, ?, ?, ?, ?, ?)";
			pstm = conn.prepareStatement(sql);
			pstm.setString(1, vo2.getCarnum());
			pstm.setString(2, vo2.getCartype());
			pstm.setString(3, vo2.getCarname());
			pstm.setString(4, vo2.getCarstat());
			pstm.setInt(5, vo2.getRentalfee());
			pstm.setInt(6, vo2.getRunfee());
			pstm.setInt(7, vo2.getOilfee());
			result = pstm.executeUpdate();
			if (result > 0) {
				result = 1;
			}
		} catch (SQLException e) {
			// 참고 사이트 : http://rosebud90.tistory.com/entry/18-Oracle-Exception-%EC%98%88%EC%99%B8%EC%B2%98%EB%A6%AC
			String[] except = e.toString().split(" ");
			if (except[1].equals("ORA-00001:")) { // 프라이머리키 값 중복 오류
				result = 2;
			}
		} catch (Exception e) {
			return 0;
		} finally {
			close();
		}
		return result; // 0. 알 수 없는 회원가입 오류, 1. 회원가입 성공, 2. 아이디 중복 오류  
	}

	public int showMeTheMoney() {
		int result = 0;
		try {
			conn = DBConnection.getConn();
			// SELECT SUM(fee) FROM rent GROUP BY ROLLUP(fee);
			String sql = "SELECT SUM(fee) FROM rent GROUP BY ROLLUP(fee)";
			result = pstm.executeUpdate();
			System.out.println(result);
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			close();
		}
		return result;
	}
}
